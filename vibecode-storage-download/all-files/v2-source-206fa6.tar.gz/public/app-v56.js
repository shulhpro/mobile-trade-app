// Mobile Trade App - Frontend Logic
let currentCompany = null;
let companies = [];
let products = [];
let orderItems = {};
let currentLocation = null;
let visitPhotos = [];
let currentTask = null;
let userContext = null;
let selectedProjectId = null;
let sections = [];
let currentSectionId = null;
let isSubmitting = false;

// Clear cache and reload app
async function clearCacheAndReload() {
  if ('caches' in window) {
    try {
      const cacheNames = await caches.keys();
      await Promise.all(cacheNames.map(name => caches.delete(name)));
      console.log('Cache cleared');
    } catch (e) {
      console.error('Error clearing cache:', e);
    }
  }
  
  // Unregister service worker
  if ('serviceWorker' in navigator) {
    try {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map(reg => reg.unregister()));
      console.log('Service workers unregistered');
    } catch (e) {
      console.error('Error unregistering SW:', e);
    }
  }
  
  // Force reload with cache bypass
  window.location.reload(true);
}

// Initialize immediately if DOM is ready
function initApp() {
  loadUserContext();
  loadCompanies();
  setupEventListeners();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

// Load user context (info + workgroups + department head)
async function loadUserContext() {
  try {
    const response = await fetch('/api/user-context');
    const data = await response.json();
    userContext = data;
    
    if (data.user) {
      const user = data.user;
      document.getElementById('userInfo').textContent = 
        (user.name || '') + ' ' + (user.lastName || '').trim() || user.email || 'Пользователь';
    }
    
    // Handle project selection
    if (data.workgroups && data.workgroups.length > 0) {
      if (data.workgroups.length === 1) {
        // Auto-select if only one project
        selectedProjectId = data.workgroups[0].id;
        console.log('Auto-selected project:', data.workgroups[0].name);
      } else {
        // Show project selector
        renderProjectSelector(data.workgroups);
      }
    }
  } catch (error) {
    console.error('Error loading user context:', error);
  }
}

// Render project selector
function renderProjectSelector(workgroups) {
  const container = document.getElementById('projectSelectorContainer');
  const select = document.getElementById('projectSelect');
  
  if (!container || !select) {
    console.error('Project selector elements not found');
    return;
  }
  
  // Clear and populate select
  select.innerHTML = '<option value="">-- Выберите проект --</option>';
  workgroups.forEach(g => {
    const option = document.createElement('option');
    option.value = g.id;
    option.textContent = g.name;
    select.appendChild(option);
  });
  
  // Add change handler
  select.onchange = function() {
    selectedProjectId = this.value ? parseInt(this.value) : null;
    console.log('Selected project:', selectedProjectId);
  };
  
  // Show container
  container.style.display = 'block';
}

// Load companies
async function loadCompanies() {
  try {
    const response = await fetch('/api/companies');
    const data = await response.json();
    companies = data.result || [];
    renderCompanies(companies);
  } catch (error) {
    console.error('Error loading companies:', error);
    document.getElementById('companiesList').innerHTML = 
      '<div class="loading">Ошибка загрузки компаний</div>';
  }
}

// Render companies list
function renderCompanies(companiesList) {
  const container = document.getElementById('companiesList');
  
  if (companiesList.length === 0) {
    container.innerHTML = '<div class="loading">Компании не найдены</div>';
    return;
  }
  
  container.innerHTML = companiesList.map(company => {
    const address = company.address || company.ADDRESS || 'Адрес не указан';
    const phone = company.phone || (company.fm && company.fm.find(f => f.typeId === 'PHONE')?.value) || '';
    
    return '<div class="company-item" onclick="selectCompany(' + (company.id || company.ID) + ')">' +
      '<h3>' + escapeHtml(company.title || company.TITLE) + '</h3>' +
      '<div class="company-address">📍 ' + escapeHtml(address) + '</div>' +
      (phone ? '<div class="company-phone">📞 ' + escapeHtml(phone) + '</div>' : '') +
      '</div>';
  }).join('');
}

// Select company
async function selectCompany(companyId) {
  currentCompany = companies.find(c => (c.id || c.ID) == companyId);
  if (!currentCompany) return;
  
  // Check for existing task
  try {
    const response = await fetch('/api/tasks/' + (currentCompany.id || currentCompany.ID));
    const data = await response.json();
    currentTask = data.task;
  } catch (error) {
    console.error('Error checking task:', error);
    currentTask = null;
  }
  
  const card = document.getElementById('companyCard');
  const address = currentCompany.address || currentCompany.ADDRESS || 'Адрес не указан';
  const phone = currentCompany.phone || (currentCompany.fm && currentCompany.fm.find(f => f.typeId === 'PHONE')?.value) || 'Не указан';
  const email = currentCompany.email || (currentCompany.fm && currentCompany.fm.find(f => f.typeId === 'EMAIL')?.value) || 'Не указан';
  
  let taskInfo = '';
  if (currentTask) {
    taskInfo = '<div class="task-info" style="margin-top: 10px; padding: 10px; background: #e3f2fd; border-radius: 8px;">' +
      '<div style="font-weight: 600; color: #1976d2;">📝 Есть открытая задача</div>' +
      '<div style="font-size: 12px; color: #666; margin-top: 4px;">Новые данные будут добавлены в существующую задачу</div>' +
      '</div>';
  }
  
  card.innerHTML = '<h2>' + escapeHtml(currentCompany.title || currentCompany.TITLE) + '</h2>' +
    '<div class="detail-row"><span class="detail-label">📍 Адрес:</span><span>' + escapeHtml(address) + '</span></div>' +
    '<div class="detail-row"><span class="detail-label">📞 Телефон:</span><span>' + escapeHtml(phone) + '</span></div>' +
    '<div class="detail-row"><span class="detail-label">✉️ Email:</span><span>' + escapeHtml(email) + '</span></div>' +
    taskInfo;
  
  const companyName = currentCompany.title || currentCompany.TITLE;
  document.getElementById('visitCompanyName').textContent = companyName;
  
  showScreen('companyDetailScreen');
}

// Show screen
function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.remove('active');
  });
  document.getElementById(screenId).classList.add('active');
  window.scrollTo(0, 0);
  
  // Auto-load dashboard when opened
  if (screenId === 'dashboardScreen' && typeof loadDashboard === 'function') {
    loadDashboard();
  }
}

// Search companies
function setupEventListeners() {
  const searchInput = document.getElementById('companySearch');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase();
      const filtered = companies.filter(c => 
        (c.title || c.TITLE || '').toLowerCase().includes(query) ||
        ((c.address || c.ADDRESS) && (c.address || c.ADDRESS).toLowerCase().includes(query))
      );
      renderCompanies(filtered);
    });
    
    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') e.preventDefault();
    });
  }
}

// Visit Form
function showVisitForm() {
  currentLocation = null;
  visitPhotos = [];
  orderItems = {};
  
  document.getElementById('locationDisplay').classList.remove('active');
  document.getElementById('visitComment').value = '';
  document.getElementById('noteText').value = '';
  document.getElementById('photoInput').value = '';
  document.getElementById('photoPreview').innerHTML = '';
  
  updateOrderTotal();
  
  showScreen('visitFormScreen');
  loadProductsForOrder();
}

function getLocation() {
  if (!navigator.geolocation) {
    showToast('Геолокация не поддерживается');
    return;
  }
  
  const btn = document.querySelector('.btn-location');
  btn.textContent = '⏳ Определение...';
  
  navigator.geolocation.getCurrentPosition(
    (position) => {
      currentLocation = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      };
      
      const display = document.getElementById('locationDisplay');
      display.innerHTML = '✅ Местоположение определено<br>Широта: ' + currentLocation.latitude.toFixed(6) + '<br>Долгота: ' + currentLocation.longitude.toFixed(6);
      display.classList.add('active');
      btn.textContent = '📍 Обновить местоположение';
    },
    (error) => {
      showToast('Ошибка определения местоположения');
      btn.textContent = '📍 Определить местоположение';
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
}

// Photo handling
document.addEventListener('DOMContentLoaded', () => {
  const photoInput = document.getElementById('photoInput');
  if (photoInput) {
    photoInput.addEventListener('change', (e) => {
      const files = e.target.files;
      const preview = document.getElementById('photoPreview');
      
      Array.from(files).forEach(file => {
        visitPhotos.push(file);
        const reader = new FileReader();
        reader.onload = (e) => {
          const img = document.createElement('img');
          img.src = e.target.result;
          preview.appendChild(img);
        };
        reader.readAsDataURL(file);
      });
    });
  }
});

// Sections and Products for order
async function loadProductsForOrder() {
  // Load sections first
  await loadSections();
}

async function loadSections() {
  try {
    const response = await fetch('/api/sections');
    const data = await response.json();
    sections = data.result || [];
    renderSections();
  } catch (error) {
    console.error('Error loading sections:', error);
    document.getElementById('sectionsList').innerHTML = 
      '<div class="loading">Ошибка загрузки разделов</div>';
  }
}

function renderSections() {
  const container = document.getElementById('sectionsList');
  
  if (sections.length === 0) {
    container.innerHTML = '<div class="loading">Разделы не найдены</div>';
    return;
  }
  
  container.innerHTML = sections.map(section => {
    return '<div class="section-item" onclick="loadProductsBySection(' + section.id + ')">' +
      '<div class="section-icon">📁</div>' +
      '<div class="section-name">' + escapeHtml(section.name) + '</div>' +
      '<div class="section-arrow">→</div>' +
      '</div>';
  }).join('');
  
  // Show sections, hide products
  document.getElementById('sectionsList').style.display = 'block';
  document.getElementById('productsList').style.display = 'none';
}

async function loadProductsBySection(sectionId) {
  currentSectionId = sectionId;
  
  try {
    const response = await fetch('/api/products?sectionId=' + sectionId);
    const data = await response.json();
    products = data.result || [];
    renderProducts();
  } catch (error) {
    console.error('Error loading products:', error);
    document.getElementById('productsContainer').innerHTML = 
      '<div class="loading">Ошибка загрузки товаров</div>';
  }
}

function showSections() {
  currentSectionId = null;
  document.getElementById('sectionsList').style.display = 'block';
  document.getElementById('productsList').style.display = 'none';
}

function renderProducts() {
  const container = document.getElementById('productsContainer');
  
  if (products.length === 0) {
    container.innerHTML = '<div class="loading">Товары не найдены</div>';
    // Still show products view
    document.getElementById('sectionsList').style.display = 'none';
    document.getElementById('productsList').style.display = 'block';
    return;
  }
  
  container.innerHTML = products.map(product => {
    const productId = product.id || product.ID;
    const item = orderItems[productId];
    const qty = item ? item.quantity : 0;
    const price = parseFloat(product.price || product.PRICE || 0);
    
    return '<div class="product-item">' +
      '<div class="product-info">' +
      '<div class="product-name">' + escapeHtml(product.name || product.NAME) + '</div>' +
      '<div class="product-price">' + price.toFixed(2) + ' ₽</div>' +
      '</div>' +
      '<div class="quantity-control">' +
      '<button type="button" class="qty-btn" onclick="updateQty(' + productId + ', -1, ' + price + ')">−</button>' +
      '<span class="qty-value" id="qty-' + productId + '">' + qty + '</span>' +
      '<button type="button" class="qty-btn" onclick="updateQty(' + productId + ', 1, ' + price + ')">+</button>' +
      '</div>' +
      '</div>';
  }).join('');
  
  // Show products, hide sections
  document.getElementById('sectionsList').style.display = 'none';
  document.getElementById('productsList').style.display = 'block';
}

function updateQty(productId, delta, price) {
  const currentItem = orderItems[productId];
  const currentQty = currentItem ? currentItem.quantity : 0;
  const newQty = Math.max(0, currentQty + delta);
  
  // Find product name from current products list
  const product = products.find(p => (p.id || p.ID) == productId);
  const productName = product ? (product.name || product.NAME) : ('Товар ' + productId);
  const productPrice = price || parseFloat(product ? (product.price || product.PRICE || 0) : 0);
  
  if (newQty === 0) {
    delete orderItems[productId];
  } else {
    orderItems[productId] = {
      quantity: newQty,
      name: productName,
      price: productPrice
    };
  }
  
  document.getElementById('qty-' + productId).textContent = newQty;
  updateOrderTotal();
}

function updateOrderTotal() {
  let total = 0;
  Object.entries(orderItems).forEach(([productId, item]) => {
    const qty = typeof item === 'object' ? item.quantity : item;
    const price = typeof item === 'object' ? item.price : 0;
    total += qty * price;
  });
  document.getElementById('orderTotal').textContent = total.toFixed(2);
}

// Submit visit form - saves to ONE task per company
async function submitVisit(closeVisit) {
  closeVisit = closeVisit || false;
  
  // Prevent double submission
  if (isSubmitting) {
    console.log('Already submitting, please wait...');
    return;
  }
  
  isSubmitting = true;
  showLoadingOverlay(closeVisit);
  
  const formData = new FormData();
  formData.append('companyId', currentCompany.id || currentCompany.ID);
  formData.append('subject', 'Визит к ' + (currentCompany.title || currentCompany.TITLE));
  formData.append('description', document.getElementById('visitComment').value);
  formData.append('noteText', document.getElementById('noteText').value);
  formData.append('closeVisit', closeVisit ? 'true' : 'false');
  
  // Add project/group
  if (selectedProjectId) {
    formData.append('groupId', selectedProjectId);
  }
  
  // Add location
  if (currentLocation) {
    formData.append('location', JSON.stringify(currentLocation));
  }
  
  // Add order data
  if (Object.keys(orderItems).length > 0) {
    const items = Object.entries(orderItems).map(([productId, item]) => {
      const qty = typeof item === 'object' ? item.quantity : item;
      const name = typeof item === 'object' ? item.name : ('Товар ' + productId);
      const price = typeof item === 'object' ? item.price : 0;
      return {
        name: name,
        quantity: qty,
        price: price
      };
    });
    const total = items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    formData.append('orderData', JSON.stringify({ items: items, total: total }));
  }
  
  // Add photos
  visitPhotos.forEach(file => {
    formData.append('photos', file);
  });
  
  try {
    const response = await fetch('/api/visit', {
      method: 'POST',
      body: formData
    });
    
    const data = await response.json();
    if (data.success) {
      if (closeVisit) {
        showSuccess('Визит завершен!', 'Задача закрыта. Все данные сохранены.');
      } else {
        showSuccess('Данные сохранены!', 'Продолжайте визит или закройте его');
      }
    } else {
      showToast('Ошибка сохранения');
    }
  } catch (error) {
    console.error('Error:', error);
    showToast('Ошибка соединения');
  } finally {
    hideLoadingOverlay();
    isSubmitting = false;
  }
}

// Loading overlay
function showLoadingOverlay(isClosing) {
  const overlay = document.getElementById('loadingOverlay');
  const text = overlay.querySelector('.loading-text');
  text.textContent = isClosing ? 'Завершение визита...' : 'Сохранение данных...';
  overlay.style.display = 'flex';
}

function hideLoadingOverlay() {
  const overlay = document.getElementById('loadingOverlay');
  overlay.style.display = 'none';
}

// Success screen
function showSuccess(title, message) {
  document.getElementById('successTitle').textContent = title;
  document.getElementById('successMessage').textContent = message;
  showScreen('successScreen');
}

// Toast
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}

// Escape HTML
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Service Worker for PWA
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(console.error);
}










// Dashboard functions
async function loadDashboard() {
  const from = document.getElementById('dashboardFrom').value;
  const to = document.getElementById('dashboardTo').value;
  
  try {
    showToast('Загрузка дашборда...');
    
    let url = '/api/dashboard';
    const params = [];
    if (from) params.push('from=' + from);
    if (to) params.push('to=' + to);
    if (params.length > 0) url += '?' + params.join('&');
    
    const response = await fetch(url);
    const data = await response.json();
    
    if (data.success) {
      renderDashboard(data.dashboard);
      showToast('Дашборд обновлен');
    } else {
      showToast('Ошибка загрузки дашборда');
    }
  } catch (error) {
    console.error('Error loading dashboard:', error);
    showToast('Ошибка загрузки дашборда');
  }
}

function renderDashboard(dashboard) {
  document.getElementById("totalVisits").textContent = dashboard.totalVisits;
  document.getElementById("totalOrders").textContent = dashboard.totalOrders;
  document.getElementById("totalAmount").textContent = formatMoney(dashboard.totalOrderAmount);
  
  const employeesTbody = document.querySelector("#employeesTable tbody");
  employeesTbody.innerHTML = "";
  
  if (dashboard.employeesList && dashboard.employeesList.length > 0) {
    dashboard.employeesList.forEach(emp => {
      const row = document.createElement("tr");
      row.className = "employee-row";
      row.innerHTML = "<td><strong>" + escapeHtml(emp.name) + "</strong></td>" +
        "<td>" + emp.visits + "</td>" +
        "<td>" + emp.orders + "</td>" +
        "<td class=\"amount\">" + formatMoney(emp.orderAmount) + "</td>" +
        "<td><button class=\"btn-toggle\" onclick=\"toggleEmployeeClients(this)\">&#9660; Клиенты (" + Object.keys(emp.clientsDetails || {}).length + ")</button></td>";
      employeesTbody.appendChild(row);
      
      const detailsRow = document.createElement("tr");
      detailsRow.className = "client-details-row";
      detailsRow.style.display = "none";
      
      const clientsDetails = Object.values(emp.clientsDetails || {});
      if (clientsDetails.length > 0) {
        let clientsHtml = "";
        clientsDetails.forEach(client => {
          clientsHtml += "<div class=\"client-detail-item\">" +
            "<span class=\"client-name\">" + escapeHtml(client.name) + "</span>" +
            "<span class=\"client-stats\">Визитов: " + client.visits + ", Заказов: " + client.orders + ", Сумма: " + formatMoney(client.orderAmount) + "</span>" +
            "</div>";
        });
        detailsRow.innerHTML = "<td colspan=\"5\" class=\"client-details-cell\">" + clientsHtml + "</td>";
      } else {
        detailsRow.innerHTML = "<td colspan=\"5\" class=\"client-details-cell\">Нет данных по клиентам</td>";
      }
      employeesTbody.appendChild(detailsRow);
    });
  } else {
    employeesTbody.innerHTML = "<tr><td colspan=\"5\" style=\"text-align:center;padding:20px;color:#999;\">Нет данных</td></tr>";
  }
}

function toggleEmployeeClients(btn) {
  const row = btn.closest("tr");
  const detailsRow = row.nextElementSibling;
  if (detailsRow && detailsRow.classList.contains("client-details-row")) {
    if (detailsRow.style.display === "none") {
      detailsRow.style.display = "table-row";
      btn.innerHTML = btn.innerHTML.replace("&#9660;", "&#9650;");
    } else {
      detailsRow.style.display = "none";
      btn.innerHTML = btn.innerHTML.replace("&#9650;", "&#9660;");
    }
  }
}
function formatMoney(amount) {
  if (!amount || amount === 0) return '0 ₽';
  return amount.toLocaleString('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ₽';
}

// Set default dates for dashboard (current month)
function initDashboardDates() {
  const now = new Date();
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
  
  document.getElementById('dashboardFrom').value = firstDay.toISOString().split('T')[0];
  document.getElementById('dashboardTo').value = now.toISOString().split('T')[0];
}

// Initialize dashboard dates when app loads
document.addEventListener('DOMContentLoaded', initDashboardDates);
