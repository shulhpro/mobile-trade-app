﻿// Mobile Trade App - deployed from GitHub
// ===== STATE =====
let companies = [];
let products = [];
let catalogSections = [];
let currentSection = null;
let currentCompany = null;
let visitData = {
    companyId: null,
    companyName: '',
    coordinates: null,
    photos: [],
    notes: '',
    order: {}
};

// ===== API =====
const API_BASE = '/api';

async function apiCall(endpoint, options = {}) {
    const url = API_BASE + endpoint;
    const res = await fetch(url, options);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
}

// ===== NAVIGATION =====
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    window.scrollTo(0, 0);
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast ' + type;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}


function showSkeleton(count = 6) {
    const container = document.getElementById('companiesList');
    container.innerHTML = `<div class="skeleton-container">${Array(count).fill(0).map(() => `
        <div class="skeleton-item">
            <div class="skeleton-icon"></div>
            <div class="skeleton-content">
                <div class="skeleton-line medium"></div>
                <div class="skeleton-line short"></div>
            </div>
        </div>
    `).join('')}</div>`;
}
// ===== COMPANIES =====
async function loadCompanies() {
    const list = document.getElementById('companiesList');
    showSkeleton();
    try {
        const data = await apiCall('/companies');
        companies = Array.isArray(data) ? data : (data.companies || []);
        renderCompanies(companies);
    } catch (err) {
        list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x26A0;</div><p>Load error</p><button class="btn btn-primary" onclick="loadCompanies()" style="margin-top:16px">Retry</button></div>';
        showToast('Error loading companies', 'error');
    }
}

function renderCompanies(list) {
    const container = document.getElementById('companiesList');
    if (!list.length) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🔍</div><p>No companies found</p></div>';
        return;
    }
    container.innerHTML = list.map((c, index) => `
        <div class="company-card-item animate-slide-up" onclick="showCompanyDetail(${c.id})" style="animation-delay: ${index * 0.05}s">
            <div class="company-card-icon">🏢</div>
            <div class="company-card-content">
                <div class="company-name">${escapeHtml(c.name)}</div>
                <div class="company-address">${escapeHtml(c.address || 'No address')}</div>
                <div class="company-contact">
                    <span class="company-badge">${escapeHtml(c.contact || 'No contact')}</span>
                </div>
            </div>
        </div>
    `).join('');
}

function filterCompanies() {
    const query = document.getElementById('searchInput').value.toLowerCase().trim();
    document.getElementById('clearSearchBtn').style.display = query ? 'flex' : 'none';
    if (!query) {
        renderCompanies(companies);
        return;
    }
    const filtered = companies.filter(c => 
        (c.name && c.name.toLowerCase().includes(query)) ||
        (c.address && c.address.toLowerCase().includes(query))
    );
    renderCompanies(filtered);
}

function clearSearch() {
    document.getElementById('searchInput').value = '';
    document.getElementById('clearSearchBtn').style.display = 'none';
    renderCompanies(companies);
}

function showCompanyDetail(companyId) {
    currentCompany = companies.find(c => c.id === companyId);
    if (!currentCompany) return;
    
    document.getElementById('detailName').textContent = currentCompany.name || 'No name';
    document.getElementById('detailType').textContent = currentCompany.type || 'Client';
    document.getElementById('detailContact').textContent = currentCompany.contact || 'Not specified';
    
    const phoneEl = document.getElementById('detailPhone');
    if (currentCompany.phone) {
        phoneEl.textContent = currentCompany.phone;
        phoneEl.href = 'tel:' + currentCompany.phone;
    } else {
        phoneEl.textContent = '-';
        phoneEl.href = '#';
    }
    
    const emailEl = document.getElementById('detailEmail');
    if (currentCompany.email) {
        emailEl.textContent = currentCompany.email;
        emailEl.href = 'mailto:' + currentCompany.email;
    } else {
        emailEl.textContent = '-';
        emailEl.href = '#';
    }
    
    showPage('companyDetailPage');
}

// ===== VISIT FLOW =====
function startVisit() {
    if (!currentCompany) return;
    visitData = {
        companyId: currentCompany.id,
        companyName: currentCompany.name,
        coordinates: null,
        photos: [],
        notes: '',
        order: {}
    };
    currentSection = null;
    resetVisitUI();
    showPage('visitPage');
}

function resetVisitUI() {
    document.getElementById('visitNotes').value = '';
    document.getElementById('locationStatus').innerHTML = '<span>&#x23F3;</span> Waiting...';
    document.getElementById('locationStatus').className = 'status-box';
    updatePhotoGallery();
}

// ===== LOCATION =====
function getLocation() {
    const status = document.getElementById('locationStatus');
    status.innerHTML = '<span>&#x23F3;</span> Locating...';
    status.className = 'status-box';
    
    if (!navigator.geolocation) {
        status.innerHTML = '<span>&#x26A0;</span> Geolocation not supported';
        status.className = 'status-box error';
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        pos => {
            visitData.coordinates = {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
            };
            status.innerHTML = '<span>&#x2705;</span> ' + visitData.coordinates.lat.toFixed(6) + ', ' + visitData.coordinates.lng.toFixed(6);
            status.className = 'status-box success';
            showToast('Location detected', 'success');
        },
        err => {
            status.innerHTML = '<span>&#x26A0;</span> Location error';
            status.className = 'status-box error';
            showToast('Geolocation error', 'error');
        },
        { enableHighAccuracy: true, timeout: 10000 }
    );
}

// ===== PHOTOS =====
function resizeImage(file, maxWidth = 800, maxHeight = 800, quality = 0.7) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = e => {
            const img = new Image();
            img.onload = () => {
                let width = img.width;
                let height = img.height;
                
                if (width > height) {
                    if (width > maxWidth) {
                        height *= maxWidth / width;
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width *= maxHeight / height;
                        height = maxHeight;
                    }
                }
                
                const canvas = document.createElement('canvas');
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function handlePhoto(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    try {
        showToast('Processing photo...', 'info');
        const resized = await resizeImage(file, 800, 800, 0.7);
        visitData.photos.push(resized);
        updatePhotoGallery();
        showToast('Photo added', 'success');
    } catch (err) {
        showToast('Error processing photo', 'error');
    }
    event.target.value = '';
}

function updatePhotoGallery() {
    const gallery = document.getElementById('photoGallery');
    const countBadge = document.getElementById('photoCount');
    
    // Update count badge
    if (countBadge) {
        countBadge.textContent = visitData.photos.length;
        countBadge.style.display = visitData.photos.length > 0 ? 'inline-block' : 'none';
    }
    
    if (visitData.photos.length === 0) {
        gallery.innerHTML = '<div class="photo-empty">No photos yet</div>';
        return;
    }
    
    gallery.innerHTML = visitData.photos.map((p, i) => `
        <div class="photo-item" onclick="viewPhoto(${i})" title="Photo ${i + 1}">
            <span>&#x1F4F7;</span>
            <span class="photo-number">${i + 1}</span>
            <span class="photo-delete" onclick="deletePhoto(event, ${i})">&#x2715;</span>
        </div>
    `).join('');
}

function viewPhoto(index) {
    // Show photo in a modal or new window
    const photo = visitData.photos[index];
    if (photo) {
        // Create temporary modal
        const modal = document.createElement('div');
        modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.95);z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px;';
        modal.innerHTML = `
            <img src="${photo}" style="max-width:100%;max-height:80vh;border-radius:12px;object-fit:contain;" onclick="event.stopPropagation()">
            <div style="position:absolute;bottom:40px;left:0;right:0;text-align:center;color:#fff;font-size:17px;">
                Photo ${index + 1} of ${visitData.photos.length}
            </div>
            <button onclick="this.parentElement.remove()" style="position:absolute;top:20px;right:20px;background:rgba(255,255,255,0.2);border:none;color:#fff;width:40px;height:40px;border-radius:50%;font-size:20px;cursor:pointer;">&#x2715;</button>
        `;
        modal.onclick = () => modal.remove();
        document.body.appendChild(modal);
    }
}

function deletePhoto(event, index) {
    event.stopPropagation();
    if (confirm('Delete photo ' + (index + 1) + '?')) {
        visitData.photos.splice(index, 1);
        updatePhotoGallery();
        showToast('Photo deleted', 'success');
    }
}

// ===== ORDER PAGE =====
function openOrderPage() {
    showPage('orderPage');
    loadCatalogSections();
}

function saveOrderAndBack() {
    showToast('Order saved', 'success');
    showPage('visitPage');
}

// ===== CATALOG SECTIONS & PRODUCTS =====
async function loadCatalogSections() {
    const container = document.getElementById('sectionsList');
    container.innerHTML = '<div class="loading">Loading sections...</div>';
    
    try {
        const data = await apiCall('/catalog-sections');
        catalogSections = Array.isArray(data) ? data : (data.sections || []);
        renderSections();
    } catch (err) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x26A0;</div><p>Error loading sections</p></div>';
        showToast('Error loading catalog sections', 'error');
    }
}

function renderSections() {
    const container = document.getElementById('sectionsList');
    const productsContainer = document.getElementById('productsContainer');
    
    if (!catalogSections.length) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x1F4C1;</div><p>No sections found</p></div>';
        return;
    }
    
    container.innerHTML = catalogSections.map(s => 
        '<div class="section-card" onclick="showSectionProducts(' + s.id + ')">' +
        '<div class="section-icon">&#x1F4C1;</div>' +
        '<div class="section-name">' + escapeHtml(s.name) + '</div>' +
        '<div class="section-arrow">&#x2192;</div>' +
        '</div>'
    ).join('');
    
    container.style.display = 'grid';
    productsContainer.style.display = 'none';
    document.getElementById('backToSections').style.display = 'none';
    document.getElementById('currentSectionTitle').style.display = 'none';
}

async function showSectionProducts(sectionId) {
    currentSection = catalogSections.find(s => s.id === sectionId);
    if (!currentSection) return;
    
    const container = document.getElementById('sectionsList');
    const productsContainer = document.getElementById('productsContainer');
    const productsList = document.getElementById('productsList');
    const backButton = document.getElementById('backToSections');
    const sectionTitle = document.getElementById('currentSectionTitle');
    
    container.style.display = 'none';
    productsContainer.style.display = 'block';
    backButton.style.display = 'flex';
    sectionTitle.style.display = 'block';
    sectionTitle.textContent = currentSection.name;
    
    productsList.innerHTML = '<div class="loading">Loading products...</div>';
    
    try {
        const data = await apiCall('/products?sectionId=' + sectionId);
        products = Array.isArray(data) ? data : (data.products || []);
        renderProducts();
    } catch (err) {
        productsList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x26A0;</div><p>Error loading products</p></div>';
        showToast('Error loading products', 'error');
    }
}

function backToSections() {
    currentSection = null;
    const container = document.getElementById('sectionsList');
    const productsContainer = document.getElementById('productsContainer');
    const backButton = document.getElementById('backToSections');
    const sectionTitle = document.getElementById('currentSectionTitle');
    
    container.style.display = 'grid';
    productsContainer.style.display = 'none';
    backButton.style.display = 'none';
    sectionTitle.style.display = 'none';
    
    renderSections();
}

function renderProducts() {
    const list = document.getElementById('productsList');
    if (!products.length) {
        list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x1F6D2;</div><p>No products in this section</p></div>';
        return;
    }
    list.innerHTML = products.map(p => {
        const qty = visitData.order[p.id] || 0;
        const total = (p.price || 0) * qty;
        return '<div class="product-item"><div class="product-info"><div class="product-name">' + escapeHtml(p.name) + '</div><div class="product-price">' + formatPrice(p.price) + ' / ' + escapeHtml(p.unit || 'pc') + '</div></div><div class="product-controls"><button class="qty-btn" onclick="updateQty(' + p.id + ', -1)">&#x2212;</button><span class="qty-value" id="qty-' + p.id + '">' + qty + '</span><button class="qty-btn" onclick="updateQty(' + p.id + ', 1)">&#x2B;</button></div><div class="product-total" id="total-' + p.id + '">' + formatPrice(total) + '</div></div>';
    }).join('');
    updateOrderSummary();
}

function updateQty(productId, delta) {
    const current = visitData.order[productId] || 0;
    const newQty = Math.max(0, current + delta);
    if (newQty === 0) {
        delete visitData.order[productId];
    } else {
        visitData.order[productId] = newQty;
    }
    
    const qtyEl = document.getElementById('qty-' + productId);
    const totalEl = document.getElementById('total-' + productId);
    if (qtyEl) qtyEl.textContent = newQty;
    
    const product = products.find(p => p.id === productId);
    if (totalEl && product) {
        totalEl.textContent = formatPrice((product.price || 0) * newQty);
    }
    
    updateOrderSummary();
}

function updateOrderSummary() {
    let totalItems = 0;
    let totalAmount = 0;
    Object.entries(visitData.order).forEach(([id, qty]) => {
        const product = products.find(p => p.id === parseInt(id));
        if (product) {
            totalItems += qty;
            totalAmount += (product.price || 0) * qty;
        }
    });
    document.getElementById('totalItems').textContent = totalItems;
    document.getElementById('totalAmount').innerHTML = formatPrice(totalAmount) + ' &#x20BD;';
}

// ===== FINISH VISIT =====
async function finishVisit() {
    console.log('finishVisit called', visitData);
    
    try {
        // Validate visit data
        if (!visitData || !visitData.companyId) {
            showToast('Error: Company not selected', 'error');
            return;
        }
        
        // Get notes
        const notesEl = document.getElementById('visitNotes');
        visitData.notes = notesEl ? notesEl.value.trim() : '';
        
        // Build order array safely
        let orderItems = [];
        try {
            if (visitData.order && typeof visitData.order === 'object') {
                orderItems = Object.entries(visitData.order).map(([id, qty]) => {
                    const product = products.find(p => p.id === parseInt(id));
                    return {
                        productId: parseInt(id),
                        name: product ? product.name : 'Unknown',
                        quantity: qty,
                        price: product ? product.price : 0
                    };
                });
            }
        } catch (e) {
            console.error('Order parsing error:', e);
        }
        
        const payload = {
            companyId: visitData.companyId,
            companyName: visitData.companyName,
            coordinates: visitData.coordinates,
            photos: visitData.photos || [],
            notes: visitData.notes,
            order: orderItems
        };
        
        console.log('Sending payload:', payload);
        
        const result = await apiCall('/visits', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        console.log('Visit saved:', result);
        visitData.visitId = result.id;
        document.getElementById('successModal').classList.add('active');
    } catch (err) {
        console.error('finishVisit error:', err);
        showToast('Error saving visit: ' + (err.message || 'Unknown error'), 'error');
    }
}

function closeModal() {
    document.getElementById('successModal').classList.remove('active');
    showPage('companiesPage');
    resetVisit();
}

async function createTask() {
    try {
        const visitId = visitData.visitId;
        if (!visitId) {
            showToast('Visit ID not found', 'error');
            return;
        }
        await apiCall('/visits/' + visitId + '/create-task', { method: 'POST' });
        showToast('Task created as completed', 'success');
    } catch (err) {
        showToast('Error creating task', 'error');
    }
    closeModal();
}

function resetVisit() {
    visitData = { companyId: null, companyName: '', coordinates: null, photos: [], notes: '', order: {} };
    currentSection = null;
    resetVisitUI();
}

// ===== UTILS =====
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatPrice(price) {
    if (price === undefined || price === null) return '0';
    return new Intl.NumberFormat('ru-RU').format(price);
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    loadCompanies();
});



// ===== PULL TO REFRESH =====
let ptrStartY = 0;
let ptrPulling = false;
const ptrThreshold = 80;

const ptrContainer = document.getElementById('pullToRefresh');
const ptrIndicator = document.getElementById('ptrIndicator');

if (ptrContainer) {
    ptrContainer.addEventListener('touchstart', (e) => {
        if (ptrContainer.scrollTop === 0) {
            ptrStartY = e.touches[0].clientY;
            ptrPulling = true;
        }
    }, { passive: true });

    ptrContainer.addEventListener('touchmove', (e) => {
        if (!ptrPulling) return;
        const diff = e.touches[0].clientY - ptrStartY;
        if (diff > 0 && ptrContainer.scrollTop === 0) {
            e.preventDefault();
            const pullDistance = Math.min(diff * 0.5, ptrThreshold + 20);
            ptrIndicator.style.transform = `translateY(${pullDistance}px)`;
            
            if (pullDistance >= ptrThreshold) {
                ptrIndicator.classList.remove('pulling');
                ptrIndicator.classList.add('ready');
            } else {
                ptrIndicator.classList.remove('ready');
                ptrIndicator.classList.add('pulling');
            }
        }
    }, { passive: false });

    ptrContainer.addEventListener('touchend', () => {
        if (!ptrPulling) return;
        ptrPulling = false;
        
        if (ptrIndicator.classList.contains('ready')) {
            ptrIndicator.classList.remove('ready');
            ptrIndicator.classList.add('refreshing');
            ptrIndicator.style.transform = `translateY(${ptrThreshold}px)`;
            
            loadCompanies().then(() => {
                ptrIndicator.classList.remove('refreshing');
                ptrIndicator.style.transform = 'translateY(0)';
            });
        } else {
            ptrIndicator.style.transform = 'translateY(0)';
            ptrIndicator.classList.remove('pulling', 'ready');
        }
    });
}



