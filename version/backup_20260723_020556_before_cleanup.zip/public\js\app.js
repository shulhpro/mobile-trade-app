// ===== STATE =====
let companies = [];
let products = [];
let catalogSections = [];
let currentSection = null;
let currentCompany = null;
let visitData = {
    companyId: null,
    companyName: '',
    coordinates: null,
    photos: [],
    notes: '',
    order: {}
};

// ===== API =====
const API_BASE = '/api';

async function apiCall(endpoint, options = {}) {
    const url = API_BASE + endpoint;
    const res = await fetch(url, options);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
}

// ===== NAVIGATION =====
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    window.scrollTo(0, 0);
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast ' + type;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// ===== COMPANIES =====
async function loadCompanies() {
    const list = document.getElementById('companiesList');
    list.innerHTML = '<div class="loading">Loading companies...</div>';
    try {
        const data = await apiCall('/companies');
        companies = Array.isArray(data) ? data : (data.companies || []);
        renderCompanies(companies);
    } catch (err) {
        list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x26A0;</div><p>Load error</p><button class="btn btn-primary" onclick="loadCompanies()" style="margin-top:16px">Retry</button></div>';
        showToast('Error loading companies', 'error');
    }
}

function renderCompanies(list) {
    const container = document.getElementById('companiesList');
    if (!list.length) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x1F50D;</div><p>No companies found</p></div>';
        return;
    }
    container.innerHTML = list.map(c => '<div class="company-card-item" onclick="showCompanyDetail(' + c.id + ')"><div class="company-name">' + escapeHtml(c.name) + '</div><div class="company-address">&#x1F4CD; ' + escapeHtml(c.address || 'No address') + '</div><div class="company-contact"><span class="company-badge">&#x1F464; User ' + escapeHtml(c.contact || 'No contact') + '</span></div></div>').join('');
}

function filterCompanies() {
    const query = document.getElementById('searchInput').value.toLowerCase().trim();
    document.getElementById('clearSearchBtn').style.display = query ? 'flex' : 'none';
    if (!query) {
        renderCompanies(companies);
        return;
    }
    const filtered = companies.filter(c => 
        (c.name && c.name.toLowerCase().includes(query)) ||
        (c.address && c.address.toLowerCase().includes(query))
    );
    renderCompanies(filtered);
}

function clearSearch() {
    document.getElementById('searchInput').value = '';
    document.getElementById('clearSearchBtn').style.display = 'none';
    renderCompanies(companies);
}

function showCompanyDetail(companyId) {
    currentCompany = companies.find(c => c.id === companyId);
    if (!currentCompany) return;
    
    document.getElementById('detailName').textContent = currentCompany.name || 'No name';
    document.getElementById('detailType').textContent = currentCompany.type || 'Client';
    document.getElementById('detailContact').textContent = currentCompany.contact || 'Not specified';
    
    const phoneEl = document.getElementById('detailPhone');
    if (currentCompany.phone) {
        phoneEl.textContent = currentCompany.phone;
        phoneEl.href = 'tel:' + currentCompany.phone;
    } else {
        phoneEl.textContent = '-';
        phoneEl.href = '#';
    }
    
    const emailEl = document.getElementById('detailEmail');
    if (currentCompany.email) {
        emailEl.textContent = currentCompany.email;
        emailEl.href = 'mailto:' + currentCompany.email;
    } else {
        emailEl.textContent = '-';
        emailEl.href = '#';
    }
    
    showPage('companyDetailPage');
}

// ===== VISIT FLOW =====
function startVisit() {
    if (!currentCompany) return;
    visitData = {
        companyId: currentCompany.id,
        companyName: currentCompany.name,
        coordinates: null,
        photos: [],
        notes: '',
        order: {}
    };
    currentSection = null;
    resetVisitUI();
    showPage('visitPage');
}

function resetVisitUI() {
    document.getElementById('visitNotes').value = '';
    document.getElementById('locationStatus').innerHTML = '<span>&#x23F3;</span> Waiting...';
    document.getElementById('locationStatus').className = 'status-box';
    updatePhotoGallery();
}

// ===== LOCATION =====
function getLocation() {
    const status = document.getElementById('locationStatus');
    status.innerHTML = '<span>&#x23F3;</span> Locating...';
    status.className = 'status-box';
    
    if (!navigator.geolocation) {
        status.innerHTML = '<span>&#x26A0;</span> Geolocation not supported';
        status.className = 'status-box error';
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        pos => {
            visitData.coordinates = {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
            };
            status.innerHTML = '<span>&#x2705;</span> ' + visitData.coordinates.lat.toFixed(6) + ', ' + visitData.coordinates.lng.toFixed(6);
            status.className = 'status-box success';
            showToast('Location detected', 'success');
        },
        err => {
            status.innerHTML = '<span>&#x26A0;</span> Location error';
            status.className = 'status-box error';
            showToast('Geolocation error', 'error');
        },
        { enableHighAccuracy: true, timeout: 10000 }
    );
}

// ===== PHOTOS =====
function handlePhoto(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = e => {
        visitData.photos.push(e.target.result);
        updatePhotoGallery();
        showToast('Photo added', 'success');
    };
    reader.readAsDataURL(file);
    event.target.value = '';
}

function updatePhotoGallery() {
    const preview = document.getElementById('photoPreview');
    const gallery = document.getElementById('photoGallery');
    
    if (visitData.photos.length === 0) {
        preview.innerHTML = '<div class="photo-placeholder"><span class="photo-icon">&#x1F4F7;</span><span>No photos</span></div>';
        gallery.innerHTML = '';
        return;
    }
    
    preview.innerHTML = '<img src="' + visitData.photos[visitData.photos.length - 1] + '" alt="Latest photo">';
    gallery.innerHTML = visitData.photos.map((p, i) => '<img src="' + p + '" alt="Photo ' + (i + 1) + '" onclick="viewPhoto(' + i + ')">').join('');
}

function viewPhoto(index) {
    showToast('Photo ' + (index + 1) + ' of ' + visitData.photos.length);
}

// ===== ORDER PAGE =====
function openOrderPage() {
    showPage('orderPage');
    loadCatalogSections();
}

function saveOrderAndBack() {
    showToast('Order saved', 'success');
    showPage('visitPage');
}

// ===== CATALOG SECTIONS & PRODUCTS =====
async function loadCatalogSections() {
    const container = document.getElementById('sectionsList');
    container.innerHTML = '<div class="loading">Loading sections...</div>';
    
    try {
        const data = await apiCall('/catalog-sections');
        catalogSections = Array.isArray(data) ? data : (data.sections || []);
        renderSections();
    } catch (err) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x26A0;</div><p>Error loading sections</p></div>';
        showToast('Error loading catalog sections', 'error');
    }
}

function renderSections() {
    const container = document.getElementById('sectionsList');
    const productsContainer = document.getElementById('productsContainer');
    
    if (!catalogSections.length) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x1F4C1;</div><p>No sections found</p></div>';
        return;
    }
    
    container.innerHTML = catalogSections.map(s => 
        '<div class="section-card" onclick="showSectionProducts(' + s.id + ')">' +
        '<div class="section-icon">&#x1F4C1;</div>' +
        '<div class="section-name">' + escapeHtml(s.name) + '</div>' +
        '<div class="section-arrow">&#x2192;</div>' +
        '</div>'
    ).join('');
    
    container.style.display = 'grid';
    productsContainer.style.display = 'none';
    document.getElementById('backToSections').style.display = 'none';
    document.getElementById('currentSectionTitle').style.display = 'none';
}

async function showSectionProducts(sectionId) {
    currentSection = catalogSections.find(s => s.id === sectionId);
    if (!currentSection) return;
    
    const container = document.getElementById('sectionsList');
    const productsContainer = document.getElementById('productsContainer');
    const productsList = document.getElementById('productsList');
    const backButton = document.getElementById('backToSections');
    const sectionTitle = document.getElementById('currentSectionTitle');
    
    container.style.display = 'none';
    productsContainer.style.display = 'block';
    backButton.style.display = 'flex';
    sectionTitle.style.display = 'block';
    sectionTitle.textContent = currentSection.name;
    
    productsList.innerHTML = '<div class="loading">Loading products...</div>';
    
    try {
        const data = await apiCall('/products?sectionId=' + sectionId);
        products = Array.isArray(data) ? data : (data.products || []);
        renderProducts();
    } catch (err) {
        productsList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x26A0;</div><p>Error loading products</p></div>';
        showToast('Error loading products', 'error');
    }
}

function backToSections() {
    currentSection = null;
    const container = document.getElementById('sectionsList');
    const productsContainer = document.getElementById('productsContainer');
    const backButton = document.getElementById('backToSections');
    const sectionTitle = document.getElementById('currentSectionTitle');
    
    container.style.display = 'grid';
    productsContainer.style.display = 'none';
    backButton.style.display = 'none';
    sectionTitle.style.display = 'none';
    
    renderSections();
}

function renderProducts() {
    const list = document.getElementById('productsList');
    if (!products.length) {
        list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">&#x1F6D2;</div><p>No products in this section</p></div>';
        return;
    }
    list.innerHTML = products.map(p => {
        const qty = visitData.order[p.id] || 0;
        const total = (p.price || 0) * qty;
        return '<div class="product-item"><div class="product-info"><div class="product-name">' + escapeHtml(p.name) + '</div><div class="product-price">' + formatPrice(p.price) + ' / ' + escapeHtml(p.unit || 'pc') + '</div></div><div class="product-controls"><button class="qty-btn" onclick="updateQty(' + p.id + ', -1)">&#x2212;</button><span class="qty-value" id="qty-' + p.id + '">' + qty + '</span><button class="qty-btn" onclick="updateQty(' + p.id + ', 1)">&#x2B;</button></div><div class="product-total" id="total-' + p.id + '">' + formatPrice(total) + '</div></div>';
    }).join('');
    updateOrderSummary();
}

function updateQty(productId, delta) {
    const current = visitData.order[productId] || 0;
    const newQty = Math.max(0, current + delta);
    if (newQty === 0) {
        delete visitData.order[productId];
    } else {
        visitData.order[productId] = newQty;
    }
    
    const qtyEl = document.getElementById('qty-' + productId);
    const totalEl = document.getElementById('total-' + productId);
    if (qtyEl) qtyEl.textContent = newQty;
    
    const product = products.find(p => p.id === productId);
    if (totalEl && product) {
        totalEl.textContent = formatPrice((product.price || 0) * newQty);
    }
    
    updateOrderSummary();
}

function updateOrderSummary() {
    let totalItems = 0;
    let totalAmount = 0;
    Object.entries(visitData.order).forEach(([id, qty]) => {
        const product = products.find(p => p.id === parseInt(id));
        if (product) {
            totalItems += qty;
            totalAmount += (product.price || 0) * qty;
        }
    });
    document.getElementById('totalItems').textContent = totalItems;
    document.getElementById('totalAmount').innerHTML = formatPrice(totalAmount) + ' &#x20BD;';
}

// ===== FINISH VISIT =====
async function finishVisit() {
    visitData.notes = document.getElementById('visitNotes').value.trim();
    
    const payload = {
        companyId: visitData.companyId,
        companyName: visitData.companyName,
        coordinates: visitData.coordinates,
        photos: visitData.photos,
        notes: visitData.notes,
        order: Object.entries(visitData.order).map(([id, qty]) => {
            const product = products.find(p => p.id === parseInt(id));
            return {
                productId: parseInt(id),
                name: product ? product.name : 'Unknown',
                quantity: qty,
                price: product ? product.price : 0
            };
        })
    };
    
    try {
        const result = await apiCall('/visits', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        visitData.visitId = result.id;
        document.getElementById('successModal').classList.add('active');
    } catch (err) {
        showToast('Error saving visit', 'error');
    }
}

function closeModal() {
    document.getElementById('successModal').classList.remove('active');
    showPage('companiesPage');
    resetVisit();
}

async function createTask() {
    try {
        const visitId = visitData.visitId;
        if (!visitId) {
            showToast('Visit ID not found', 'error');
            return;
        }
        await apiCall('/visits/' + visitId + '/create-task', { method: 'POST' });
        showToast('Task created as completed', 'success');
    } catch (err) {
        showToast('Error creating task', 'error');
    }
    closeModal();
}

function resetVisit() {
    visitData = { companyId: null, companyName: '', coordinates: null, photos: [], notes: '', order: {} };
    currentSection = null;
    resetVisitUI();
}

// ===== UTILS =====
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatPrice(price) {
    if (price === undefined || price === null) return '0';
    return new Intl.NumberFormat('ru-RU').format(price);
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    loadCompanies();
});
