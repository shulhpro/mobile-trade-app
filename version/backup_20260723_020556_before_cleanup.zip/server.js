const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// API configuration
const API_KEY = 'vibe_api_B5LhuhAlxAfjnWVLTCD6RU0UsDWl6IvV_05fc97';
const VIBECODE_API = 'https://vibecode.bitrix24.tech/v1';

app.use(cors());
app.use(express.json());

// No-cache middleware for static files
app.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

app.use(express.static('public'));

const upload = multer({ dest: 'uploads/' });

if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

const db = {
  visits: [],
  orders: []
};

// Cache for current user
let currentUser = null;

// Helper to call VibeCode API
async function callVibeApi(endpoint) {
  try {
    const response = await fetch(VIBECODE_API + endpoint, {
      headers: {
        'X-Api-Key': API_KEY
      }
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json();
    return data.success ? data.data : [];
  } catch (error) {
    console.error('API Error:', error);
    return [];
  }
}

// Get current user from VibeCode API
async function getCurrentUser() {
  if (currentUser) return currentUser;
  
  try {
    const response = await fetch(VIBECODE_API + '/me', {
      headers: {
        'X-Api-Key': API_KEY
      }
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const data = await response.json();
    if (data.success && data.data) {
      currentUser = {
        id: data.data.owner?.userId || data.data.user?.id || 1,
        name: data.data.owner?.name || 'User'
      };
      console.log('Current user:', currentUser);
      return currentUser;
    }
  } catch (error) {
    console.error('Error getting current user:', error);
  }
  
  return { id: 1, name: 'User' };
}

// ============ COMPANIES API ============
app.get('/api/companies', async (req, res) => {
  try {
    const search = req.query.search?.toLowerCase() || '';
    const companies = await callVibeApi('/companies?limit=50');
    
    let result = companies.map(c => ({
      id: c.id,
      name: c.title,
      address: c.address || c.ufCrm_1508844257 || '',
      contact: c.assignedById ? 'User ' + c.assignedById : 'No contact',
      phone: c.phone || '',
      email: c.email || ''
    }));
    
    if (search) {
      result = result.filter(c => 
        c.name.toLowerCase().includes(search) || 
        c.address.toLowerCase().includes(search)
      );
    }
    
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to fetch companies' });
  }
});

app.get('/api/companies/:id', async (req, res) => {
  try {
    const companies = await callVibeApi('/companies?limit=50');
    const company = companies.find(c => c.id == req.params.id);
    if (!company) return res.status(404).json({ error: 'Company not found' });
    
    res.json({
      id: company.id,
      name: company.title,
      address: company.address || company.ufCrm_1508844257 || '',
      contact: company.assignedById ? 'User ' + company.assignedById : 'No contact',
      phone: company.phone || '',
      email: company.email || ''
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch company' });
  }
});

// ============ CATALOG SECTIONS API ============
app.get('/api/catalog-sections', async (req, res) => {
  try {
    const sections = await callVibeApi('/catalog-sections?filter[iblockId]=24&limit=50');
    
    const result = sections.map(s => ({
      id: s.id,
      name: s.name,
      code: s.code,
      sort: s.sort || 500
    })).sort((a, b) => a.sort - b.sort);
    
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to fetch catalog sections' });
  }
});

// ============ PRODUCTS API ============
app.get('/api/products', async (req, res) => {
  try {
    const sectionId = req.query.sectionId;
    let endpoint = '/products?limit=50';
    
    if (sectionId) {
      endpoint = '/products?filter[sectionId]=' + sectionId + '&limit=50';
    }
    
    const products = await callVibeApi(endpoint);
    
    const result = products.map(p => ({
      id: p.id,
      name: p.name,
      price: p.price || 0,
      unit: p.measure || 'pc',
      sectionId: p.sectionId
    }));
    
    res.json(result);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// ============ VISITS API ============
app.post('/api/visits', async (req, res) => {
  const user = await getCurrentUser();
  const visit = {
    id: Date.now(),
    companyId: req.body.companyId,
    companyName: req.body.companyName,
    userId: user.id,
    userName: user.name,
    startTime: new Date().toISOString(),
    coords: null,
    photos: [],
    note: '',
    order: { items: [], total: 0 },
    status: 'in_progress'
  };
  db.visits.push(visit);
  res.json(visit);
});

app.get('/api/visits', (req, res) => {
  res.json(db.visits);
});

app.get('/api/visits/:id', (req, res) => {
  const visit = db.visits.find(v => v.id == req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  res.json(visit);
});

app.patch('/api/visits/:id/coords', (req, res) => {
  const visit = db.visits.find(v => v.id == req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  visit.coords = req.body.coords;
  res.json({ success: true, coords: visit.coords });
});

app.post('/api/visits/:id/photos', upload.single('photo'), (req, res) => {
  const visit = db.visits.find(v => v.id == req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  if (req.file) {
    const photoUrl = '/uploads/' + req.file.filename;
    visit.photos.push({
      url: photoUrl,
      filename: req.file.originalname,
      uploadedAt: new Date().toISOString()
    });
    res.json({ success: true, photo: visit.photos[visit.photos.length - 1] });
  } else {
    res.status(400).json({ error: 'No photo uploaded' });
  }
});

app.patch('/api/visits/:id/note', (req, res) => {
  const visit = db.visits.find(v => v.id == req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  visit.note = req.body.note || '';
  res.json({ success: true, note: visit.note });
});

app.patch('/api/visits/:id/order', (req, res) => {
  const visit = db.visits.find(v => v.id == req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  visit.order = req.body.order || { items: [], total: 0 };
  const existingOrderIndex = db.orders.findIndex(o => o.visitId == visit.id);
  const orderData = {
    visitId: visit.id,
    companyId: visit.companyId,
    companyName: visit.companyName,
    items: visit.order.items,
    total: visit.order.total,
    createdAt: new Date().toISOString()
  };
  if (existingOrderIndex >= 0) {
    db.orders[existingOrderIndex] = orderData;
  } else {
    db.orders.push(orderData);
  }
  res.json({ success: true, order: visit.order });
});

app.post('/api/visits/:id/complete', async (req, res) => {
  const visit = db.visits.find(v => v.id == req.params.id);
  if (!visit) return res.status(404).json({ error: 'Visit not found' });
  visit.status = 'completed';
  visit.endTime = new Date().toISOString();
  res.json({ success: true, visit, message: 'Visit completed successfully' });
});

app.get('/api/orders', (req, res) => {
  res.json(db.orders);
});

app.get('/api/orders/:visitId', (req, res) => {
  const order = db.orders.find(o => o.visitId == req.params.visitId);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

app.post('/api/visits/:id/create-task', async (req, res) => {
  try {
    const visit = db.visits.find(v => v.id == req.params.id);
    if (!visit) return res.status(404).json({ error: 'Visit not found' });
    
    // Use visit userId or get current user
    const responsibleId = visit.userId || (await getCurrentUser()).id;
    
    // Create task in Bitrix24 via VibeCode API
    const taskData = {
      title: 'Visit: ' + visit.companyName,
      description: visit.note || 'Visit completed',
      responsibleId: responsibleId,
      priority: 2,
      status: 5
    };
    
    const response = await fetch(VIBECODE_API + '/tasks', {
      method: 'POST',
      headers: {
        'X-Api-Key': API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(taskData)
    });
    
    if (!response.ok) {
      throw new Error('HTTP ' + response.status);
    }
    
    const result = await response.json();
    
    res.json({
      success: true,
      message: 'Task created in Bitrix24',
      taskId: result.data?.id || result.data?.task?.id,
      responsibleId: responsibleId,
      visit: {
        id: visit.id,
        companyName: visit.companyName
      }
    });
  } catch (error) {
    console.error('Task creation error:', error);
    res.status(500).json({ 
      error: 'Failed to create task',
      message: error.message 
    });
  }
});

app.use('/uploads', express.static('uploads'));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log('Server running on port ' + PORT);
});