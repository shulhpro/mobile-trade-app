﻿// ===== STATE =====
let companies = [];
let products = [];
let currentCompany = null;
let currentStep = 1;
let visitData = {
    companyId: null,
    companyName: '',
    coordinates: null,
    photos: [],
    notes: '',
    order: {}
};

// ===== API =====
const API_BASE = '/api';

async function apiCall(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const res = await fetch(url, options);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
}

// ===== NAVIGATION =====
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(pageId).classList.add('active');
    window.scrollTo(0, 0);
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

// ===== COMPANIES =====
async function loadCompanies() {
    const list = document.getElementById('companiesList');
    list.innerHTML = '<div class="loading">Загрузка компаний...</div>';
    try {
       const data = await apiCall('/companies');
        companies = Array.isArray(data) ? data : (data.companies || []);
        renderCompanies(companies);
    } catch (err) {
        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">&#x26A0;</div>
                <p>Ошибка загрузки</p>
                <button class="btn btn-primary" onclick="loadCompanies()" style="margin-top:16px">Повторить</button>
            </div>`;
        showToast('Ошибка загрузки компаний', 'error');
    }
}

function renderCompanies(list) {
    const container = document.getElementById('companiesList');
    if (!list.length) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">&#x1F50D;</div>
                <p>Компании не найдены</p>
            </div>`;
        return;
    }
    container.innerHTML = list.map(c => `
        <div class="company-card-item" onclick="showCompanyDetail(${c.id})">
            <div class="company-name">${escapeHtml(c.name)}</div>
            <div class="company-address">&#x1F4CD; ${escapeHtml(c.address || 'Адрес не указан')}</div>
            <div class="company-contact">
                <span class="company-badge">&#x1F464; ${escapeHtml(c.contact || 'Не указан')}</span>
            </div>
        </div>
    `).join('');
}

function filterCompanies() {
    const query = document.getElementById('searchInput').value.toLowerCase().trim();
    document.getElementById('clearSearchBtn').style.display = query ? 'flex' : 'none';
    if (!query) {
        renderCompanies(companies);
        return;
    }
    const filtered = companies.filter(c => 
        (c.name && c.name.toLowerCase().includes(query)) ||
        (c.address && c.address.toLowerCase().includes(query))
    );
    renderCompanies(filtered);
}

function clearSearch() {
    document.getElementById('searchInput').value = '';
    document.getElementById('clearSearchBtn').style.display = 'none';
    renderCompanies(companies);
}

function showCompanyDetail(companyId) {
    currentCompany = companies.find(c => c.id === companyId);
    if (!currentCompany) return;
    
    document.getElementById('detailName').textContent = currentCompany.name || 'Название не указано';
    document.getElementById('detailType').textContent = currentCompany.type || 'Клиент';
    document.getElementById('detailContact').textContent = currentCompany.contact || 'Не указан';
    
    const phoneEl = document.getElementById('detailPhone');
    if (currentCompany.phone) {
        phoneEl.textContent = currentCompany.phone;
        phoneEl.href = `tel:${currentCompany.phone}`;
    } else {
        phoneEl.textContent = '-';
        phoneEl.href = '#';
    }
    
    const emailEl = document.getElementById('detailEmail');
    if (currentCompany.email) {
        emailEl.textContent = currentCompany.email;
        emailEl.href = `mailto:${currentCompany.email}`;
    } else {
        emailEl.textContent = '-';
        emailEl.href = '#';
    }
    
    showPage('companyDetailPage');
}

// ===== VISIT FLOW =====
function startVisit() {
    if (!currentCompany) return;
    visitData = {
        companyId: currentCompany.id,
        companyName: currentCompany.name,
        coordinates: null,
        photos: [],
        notes: '',
        order: {}
    };
    currentStep = 1;
    updateStepUI();
    showPage('visitPage');
}

function updateStepUI() {
    document.querySelectorAll('.step-content').forEach(s => s.classList.remove('active'));
    document.getElementById(`step${currentStep}`).classList.add('active');
    document.getElementById('stepTitle').textContent = `Шаг ${currentStep}`;
    document.getElementById('stepIndicator').textContent = `${currentStep} / 4`;
}

function nextStep() {
 if (currentStep < 4) {
        currentStep++;
        updateStepUI();
        if (currentStep === 4) loadProducts();
    } else {
        finishVisit();
    }
}

function prevStep() {
    if (currentStep > 1) {
        currentStep--;
        updateStepUI();
    } else {
        showPage('companyDetailPage');
    }
}

// ===== STEP 1: LOCATION =====
function getLocation() {
    const status = document.getElementById('locationStatus');
    status.innerHTML = '<span>&#x23F3;</span> Определение...';
    status.className = 'status-box';
    
    if (!navigator.geolocation) {
        status.innerHTML = '<span>&#x26A0;</span> Геолокация не поддерживается';
        status.className = 'status-box error';
        return;
    }
    
    navigator.geolocation.getCurrentPosition(
        pos => {
            visitData.coordinates = {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude
            };
            status.innerHTML = `<span>&#x2705;</span> ${visitData.coordinates.lat.toFixed(6)}, ${visitData.coordinates.lng.toFixed(6)}`;
            status.className = 'status-box success';
            showToast('Координаты определены', 'success');
        },
        err => {
            status.innerHTML = '<span>&#x26A0;</span> Ошибка определения местоположения';
            status.className = 'status-box error';
            showToast('Ошибка геолокации', 'error');
        },
        { enableHighAccuracy: true, timeout: 10000 }
    );
}

// ===== STEP 2: PHOTOS =====
function handlePhoto(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = e => {
        visitData.photos.push(e.target.result);
        updatePhotoGallery();
        showToast('Фото добавлено', 'success');
    };
    reader.readAsDataURL(file);
    event.target.value = '';
}

function updatePhotoGallery() {
    const preview = document.getElementById('photoPreview');
    const gallery = document.getElementById('photoGallery');
    
    if (visitData.photos.length === 0) {
        preview.innerHTML = `
            <div class="photo-placeholder">
                <span class="photo-icon">&#x1F4F7;</span>
                <span>Нет фото</span>
            </div>`;
        gallery.innerHTML = '';
        return;
    }
    
    preview.innerHTML = `<img src="${visitData.photos[visitData.photos.length - 1]}" alt="Latest photo">`;
    gallery.innerHTML = visitData.photos.map((p, i) => `
        <img src="${p}" alt="Photo ${i + 1}" onclick="viewPhoto(${i})">
    `).join('');
}

function viewPhoto(index) {
    // Simple photo viewer - could be expanded
    showToast(`Фото ${index + 1} из ${visitData.photos.length}`);
}

// ===== STEP 3: NOTES =====
function getNotes() {
    return document.getElementById('visitNotes').value.trim();
}

// ===== STEP 4: PRODUCTS =====
async function loadProducts() {
    const list = document.getElementById('productsList');
    list.innerHTML = '<div class="loading">Загрузка товаров...</div>';
    try {
       const data = await apiCall('/products');
        products = Array.isArray(data) ? data : (data.products || []);
        renderProducts();
    } catch (err) {
        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">&#x26A0;</div>
                <p>Ошибка загрузки товаров</p>
            </div>`;
        showToast('Ошибка загрузки товаров', 'error');
    }
}

function renderProducts() {
    const list = document.getElementById('productsList');
    if (!products.length) {
        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-state-icon">&#x1F6D2;</div>
                <p>Товары не найдены</p>
            </div>`;
        return;
    }
    list.innerHTML = products.map(p => {
        const qty = visitData.order[p.id] || 0;
        const total = (p.price || 0) * qty;
        return `
            <div class="product-item">
                <div class="product-info">
                    <div class="product-name">${escapeHtml(p.name)}</div>
                    <div class="product-price">${formatPrice(p.price)} / ${escapeHtml(p.unit || 'шт')}</div>
                </div>
                <div class="product-controls">
                    <button class="qty-btn" onclick="updateQty(${p.id}, -1)">&#x2212;</button>
                    <span class="qty-value" id="qty-${p.id}">${qty}</span>
                    <button class="qty-btn" onclick="updateQty(${p.id}, 1)">&#x2B;</button>
                </div>
                <div class="product-total" id="total-${p.id}">${formatPrice(total)}</div>
            </div>
        `;
    }).join('');
    updateOrderSummary();
}

function updateQty(productId, delta) {
    const current = visitData.order[productId] || 0;
    const newQty = Math.max(0, current + delta);
    if (newQty === 0) {
        delete visitData.order[productId];
    } else {
        visitData.order[productId] = newQty;
    }
    
    const qtyEl = document.getElementById(`qty-${productId}`);
    const totalEl = document.getElementById(`total-${productId}`);
    if (qtyEl) qtyEl.textContent = newQty;
    
    const product = products.find(p => p.id === productId);
    if (totalEl && product) {
        totalEl.textContent = formatPrice((product.price || 0) * newQty);
    }
    
    updateOrderSummary();
}

function updateOrderSummary() {
    let totalItems = 0;
    let totalAmount = 0;
    Object.entries(visitData.order).forEach(([id, qty]) => {
        const product = products.find(p => p.id === parseInt(id));
        if (product) {
            totalItems += qty;
            totalAmount += (product.price || 0) * qty;
        }
    });
    document.getElementById('totalItems').textContent = totalItems;
    document.getElementById('totalAmount').innerHTML = `${formatPrice(totalAmount)} &#x20BD;`;
}

// ===== FINISH VISIT =====
async function finishVisit() {
    visitData.notes = getNotes();
    
    const payload = {
        companyId: visitData.companyId,
        companyName: visitData.companyName,
        coordinates: visitData.coordinates,
        photos: visitData.photos,
        notes: visitData.notes,
        order: Object.entries(visitData.order).map(([id, qty]) => {
            const product = products.find(p => p.id === parseInt(id));
            return {
                productId: parseInt(id),
                name: product ? product.name : 'Unknown',
                quantity: qty,
                price: product ? product.price : 0
            };
        })
    };
    
   try {
        const result = await apiCall('/visits', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        visitData.visitId = result.id;
        document.getElementById('successModal').classList.add('active');
    } catch (err) {
        showToast('Ошибка сохранения визита', 'error');
    }
}

function closeModal() {
    document.getElementById('successModal').classList.remove('active');
    showPage('companiesPage');
    resetVisit();
}

async function createTask() {
   try {
        const visitId = visitData.visitId;
        if (!visitId) {
            showToast('Visit ID not found', 'error');
            return;
        }
        await apiCall(`/visits/${visitId}/create-task`, { method: 'POST' });
       showToast('Задача создана в Битрикс24', 'success');
   } catch (err) {
       showToast('Ошибка создания задачи', 'error');
   }
   closeModal();
}

function resetVisit() {
    visitData = { companyId: null, companyName: '', coordinates: null, photos: [], notes: '', order: {} };
    currentStep = 1;
    document.getElementById('visitNotes').value = '';
    document.getElementById('locationStatus').innerHTML = '<span>&#x23F3;</span> Ожидание...';
    document.getElementById('locationStatus').className = 'status-box';
    updatePhotoGallery();
}

// ===== UTILS =====
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatPrice(price) {
    if (price === undefined || price === null) return '0';
    return new Intl.NumberFormat('ru-RU').format(price);
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    loadCompanies();
});
